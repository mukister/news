from django.http import HttpResponse

def mangatokyo(request):
	from bs4 import BeautifulSoup
	from requests import get
	url = 'https://manga.tokyo/news/'
	response = get(url)
	html_soup = BeautifulSoup(response.text, 'html.parser')
	movie_containers = html_soup.find_all("h3", {"class": "post-list-content-ttl"})
	print(movie_containers)
	a = []
	for i in movie_containers:
		strin = str(i.find('a'))
		strrin = strin[:9] + 'https://www.crunchyroll.com'+strin[9:]+'</br>'
		a.append(strrin)
		res = str(a).replace(',','')
		ress = res.replace('[','')
		resss = ress.replace(']','')
		ressss = resss.replace("'",'')
		resssss = ressss.replace('\\','')
		
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{text-decoration: none;display:block;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style>'+'<div class="content"><a href="/">Home</a><h1>Latest News</h1>'+resssss+'</div>')


def crunchyroll(request):
	from bs4 import BeautifulSoup
	from requests import get
	url = 'https://www.crunchyroll.com/en-gb/news'
	response = get(url)
	html_soup = BeautifulSoup(response.text, 'html.parser')
	movie_containers = html_soup.find_all("li", {"class": "news-item"})
	a = []
	for i in movie_containers:
		strin = str(i.find('a'))
		strrin = strin[:9] + 'https://www.crunchyroll.com'+strin[9:]+'</br>'
		a.append(strrin)
		res = str(a).replace(',','')
		ress = res.replace('[','')
		resss = ress.replace(']','')
		ressss = resss.replace("'",'')
		resssss = ressss.replace('\\','')
		print(resssss)
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{display:block;text-decoration: none;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style>'+'<div class="content"><a href="/">Home</a><h1>Latest News</h1>'+resssss+'</div>')

def otaku(request):
	from bs4 import BeautifulSoup
	from requests import get
	url = 'https://otakumode.com/news/anime'
	response = get(url)
	html_soup = BeautifulSoup(response.text, 'html.parser')
	movie_containers = html_soup.find_all("article", {"class": "p-article p-article-list__item c-hit"})
	a = []
	for i in movie_containers:
		strin = str(i.find('a',{'class':'inherit'}))
		print(strin)
		strrin = strin[:25] + 'https://otakumode.com'+strin[25:]+'</br>'
		a.append(strrin)
		res = str(a).replace(',','')
		ress = res.replace('[','')
		resss = ress.replace(']','')
		ressss = resss.replace("'",'')
		resssss = ressss.replace('\\','')
		
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{display:block;text-decoration: none;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style>'+'<div class="content"><a href="/">Home</a><h1>Latest News</h1>'+resssss+'</div>')

def ukanime(request):
	from bs4 import BeautifulSoup
	from requests import get
	url = 'https://www.uk-anime.net/LatestNews'
	response = get(url)
	html_soup = BeautifulSoup(response.text, 'html.parser')
	movie_containers = html_soup.find_all("div", {"class": "column3 left"})
	a = []
	for i in movie_containers:
		strin = str(i.find('a'))
		print(strin)
		strrin = strin[:9] + 'https://www.uk-anime.net/'+strin[9:]+'</br>'
		a.append(strrin)
		res = str(a).replace(',','')
		ress = res.replace('[','')
		resss = ress.replace(']','')
		ressss = resss.replace("'",'')
		resssss = ressss.replace('\\','')
		
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{display:block;text-decoration: none;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style>'+'<div class="content"><a href="/">Home</a><h1>Latest News</h1>'+resssss+'</div>')

def otakuart(request):
	from bs4 import BeautifulSoup
	from requests import get
	url = 'https://otakukart.com/category/news/'
	response = get(url)
	html_soup = BeautifulSoup(response.text, 'html.parser')
	movie_containers = html_soup.find_all("h3", {"class": "entry-title td-module-title"})
	a = []
	for i in movie_containers:
		strin = str(i.find('a'))
		print(strin)
		
		a.append(strin+'</br>')
		res = str(a).replace(',','')
		ress = res.replace('[','')
		resss = ress.replace(']','')
		ressss = resss.replace("'",'')
		resssss = ressss.replace('\\','')
		
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{display:block;text-decoration: none;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style>'+'<div class="content"><a href="/">Home</a><h1>Latest News</h1>'+resssss+'</div>')

def mal(request):
	from bs4 import BeautifulSoup
	from requests import get
	url = 'https://myanimelist.net/news'
	response = get(url)
	html_soup = BeautifulSoup(response.text, 'html.parser')
	movie_containers = html_soup.find_all("div", {"class": "news-unit-right"})
	a = []
	for i in movie_containers:
		strin = str(i.find('a'))
		print(strin)
		
		a.append(strin+'</br>')
		res = str(a).replace(',','')
		ress = res.replace('[','')
		resss = ress.replace(']','')
		ressss = resss.replace("'",'')
		resssss = ressss.replace('\\','')
		
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{display:block;text-decoration: none;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style>'+'<div class="content"><a href="/">Home</a><h1>Latest News</h1>'+resssss+'</div>')


		

		
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{display:block;text-decoration: none;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style>'+'<div class="content"><a href="/">Home</a><h1>Latest News</h1>'+resssss+'</div>')


def index(request):
	return HttpResponse('<style>a{padding:10px;}a:visited{color:black;}a:link{display:block;text-decoration: none;color:black;font-size:20px;}a:hover{color:#8aab9a}.content{margin:0 auto; width:70%;border: solid;padding:10px;text-align:center;}</style><div class="content"><a href="/">Home</a></br><h1>Anime News Sources</h1><a href="/crunchyroll">Crunchyroll</a></br><a href="/otaku">Otaku</a></br><a href="/mangatokyo">Manga.Tokyo</a></br><a href="/ukanime">Uk Anime</a></br><a href="/otakuart">Otaku Art</a></br><a href="/mal">MyAnimeList News</a></br></div>')














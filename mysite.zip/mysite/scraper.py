from selenium import webdriver
driver = webdriver.Chrome('/users/sarupparajuli/desktop/chromedriver')
driver.get('https://www.animenewsnetwork.com/')
userid_element = driver.find_elements_by_tag_name('h3')


for i in range(len(userid_element)):

	print (userid_element[i].get_attribute('innerHTML'))

driver.quit()